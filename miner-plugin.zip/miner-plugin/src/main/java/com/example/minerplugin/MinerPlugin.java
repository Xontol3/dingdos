package com.example.minerplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Plugin Spigot/Paper yang menjalankan miner.jar (lihat Main.java) sebagai
 * proses terpisah di background. Dibuat untuk server pribadi milik sendiri.
 *
 * Catatan performa: mining memakai CPU penuh. Di server dengan pemain lain,
 * ini akan menurunkan TPS/performa game kalau threads diset terlalu tinggi.
 * Gunakan "low-priority: true" di config.yml dan threads yang kecil.
 */
public class MinerPlugin extends JavaPlugin {

    private Process minerProcess;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getConfig().getBoolean("auto-start", false)) {
            startMiner();
        }
    }

    @Override
    public void onDisable() {
        stopMiner();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("Pakai: /miner <start|stop|status>");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "start":
                if (minerProcess != null && minerProcess.isAlive()) {
                    sender.sendMessage("Miner sudah berjalan.");
                } else {
                    startMiner();
                    sender.sendMessage("Miner dijalankan di background.");
                }
                return true;
            case "stop":
                stopMiner();
                sender.sendMessage("Miner dihentikan.");
                return true;
            case "status":
                boolean alive = minerProcess != null && minerProcess.isAlive();
                sender.sendMessage("Status miner: " + (alive ? "berjalan" : "berhenti"));
                return true;
            default:
                sender.sendMessage("Pakai: /miner <start|stop|status>");
                return true;
        }
    }

    private void startMiner() {
        FileConfiguration cfg = getConfig();
        File jar = new File(getDataFolder(), cfg.getString("miner-jar", "miner.jar"));
        if (!jar.exists()) {
            getLogger().warning("miner.jar tidak ditemukan di " + jar.getAbsolutePath()
                    + " — taruh file miner.jar di folder plugin ini.");
            return;
        }

        List<String> cmd = new ArrayList<>();
        // "nice -n 19" membuat proses hanya memakai sisa CPU yang tidak dipakai
        // server game, supaya TPS tidak drop.
        if (cfg.getBoolean("low-priority", true) && new File("/usr/bin/nice").exists()) {
            cmd.add("nice");
            cmd.add("-n");
            cmd.add("19");
        }
        cmd.add("java");
        cmd.add("-jar");
        cmd.add(jar.getAbsolutePath());

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(getDataFolder());
        pb.redirectErrorStream(true);
        pb.redirectOutput(new File(getDataFolder(), "miner.log"));

        pb.environment().put("WALLET_ADDRESS", cfg.getString("wallet-address", ""));
        pb.environment().put("POOL_URL", cfg.getString("pool-url", ""));
        pb.environment().put("WORKER_NAME", cfg.getString("worker-name", "worker"));
        pb.environment().put("PASSWORD", cfg.getString("password", "x"));
        pb.environment().put("THREADS", String.valueOf(cfg.getInt("threads", 1)));
        String algo = cfg.getString("algo", "");
        if (algo != null && !algo.isEmpty()) {
            pb.environment().put("ALGO", algo);
        }

        try {
            minerProcess = pb.start();
            getLogger().info("Proses miner dimulai (PID " + minerProcess.pid() + "). Log: "
                    + new File(getDataFolder(), "miner.log").getAbsolutePath());
        } catch (IOException e) {
            getLogger().severe("Gagal menjalankan miner: " + e.getMessage());
        }
    }

    private void stopMiner() {
        if (minerProcess != null && minerProcess.isAlive()) {
            minerProcess.destroy();
            try {
                if (!minerProcess.waitFor(5, java.util.concurrent.TimeUnit.SECONDS)) {
                    minerProcess.destroyForcibly();
                }
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
